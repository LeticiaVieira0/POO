public class Terceirizado extends Funcionario{
    public Terceirizado(String nome, int horas, double valorHora, double custoAdicional) {
        super(nome, horas, valorHora, custoAdicional);
    }

    @Override
    public double getSalario(int horas, double valorHora, double custoAdicional){

        return (horas * valorHora) + (custoAdicional * 1.1);
    }
}
