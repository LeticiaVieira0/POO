void main() {
    Scanner leia = new Scanner(System.in);

    //Workflow com classes
    //SUPERCLASSE -> Funcionario
    //clases filhas da funcionario -> Terceirizado e Colaborador

    //Lista de funcionarios
    List<Funcionario> listaFuncionarios = new ArrayList<>();

    System.out.println("Insira o número de funcionários: ");
    int numFunc = leia.nextInt();
    int i = 0;

    while(i < numFunc){
        //limpeza de buffer
        leia.nextLine();

        System.out.println("Dados do funcionario "+i+1);

        System.out.println("Terceirizado (s/n)? ");
        String terc = leia.nextLine();

        System.out.println("Nome: ");
        String nome = leia.nextLine();

        System.out.println("Horas");
        int horas = leia.nextInt();

        System.out.println("Valor hora: ");
        double valorHora = leia.nextDouble();


        //Se for terceirizado adicionar a classe terceirizado
        //Senão adicionar a classe colaborador
        if (terc.equals("s")){
            System.out.println("Custo adicional");
            double custoAdicional = leia.nextDouble();
            listaFuncionarios.add(new Terceirizado(nome, horas, valorHora, custoAdicional));
        } else {
            listaFuncionarios.add(new Colaborador(nome, horas, valorHora, 0));
        }

        i++;
    }
    //Printando a lista de funcs
    //Espaço pra fins esteticos
    System.out.println("");
    System.out.println("PAGAMENTOS: ");
    for(Funcionario colab : listaFuncionarios){
        System.out.println(""+colab.getNome()+" - "+colab.getSalario(colab.getHoras(), colab.getValorHora(), colab.getCustoAdicional()));
    }
}