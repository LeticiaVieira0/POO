public class Colaborador extends Funcionario{
    public Colaborador(String nome, int horas, double valorHora, double custoAdicional) {
        super(nome, horas, valorHora, custoAdicional);
    }

    @Override
    public double getSalario(int horas, double valorHora, double custoAdicional){

        return (horas * valorHora);
    }
}
