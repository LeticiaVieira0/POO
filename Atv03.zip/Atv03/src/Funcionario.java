public class Funcionario {
    String nome;
    int horas;
    double valorHora;
    double custoAdicional;

    public Funcionario(String nome, int horas, double valorHora, double custoAdicional) {
        this.nome = nome;
        this.horas = horas;
        this.valorHora = valorHora;
        this.custoAdicional = custoAdicional;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    public double getCustoAdicional() {
        return custoAdicional;
    }

    public void setCustoAdicional(double custoAdicional) {
        this.custoAdicional = custoAdicional;
    }

    public double getSalario(int horas, double valorHora, double custoAdicional) {
        return (horas * valorHora);
    }
}
